CREATE TABLE `report` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `applyId` varchar(10) NOT NULL,
  `flowCost` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8